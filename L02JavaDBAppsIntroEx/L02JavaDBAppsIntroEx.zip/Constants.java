package L02JavaDBAppsIntroEx;

public enum Constants {
    ;
    static final String USER_KEY = "user";
    static final String USER_VALUE = "root";

    static final String PASSWORD_KEY = "password";
    static final String PASSWORD_VALUE = "R00ney!0";

    static final String JDBC_MYSQL_URL = "jdbc:mysql://localhost:3306/minions_db";
}
