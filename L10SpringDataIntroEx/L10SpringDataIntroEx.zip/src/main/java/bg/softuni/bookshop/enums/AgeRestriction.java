package bg.softuni.bookshop.enums;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
